# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.apps import AppConfig


class TwitterapiConfig(AppConfig):
    name = 'twitterapi'
    verbose_name = 'Twitter API crawler'
