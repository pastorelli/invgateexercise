=====
Twitter API exercise
=====

This app is used to retrieve the twitter profile information using
celery and rabbitMQ as a message broker

Requirements
-----------

This app needs celery and rabbitMQ in order to process the twitter profile requests.

In order to run celery in a command line run the following:
$ celery -A proj worker -l info
where proj is the project name

To install rabbitMQ on ubuntu/debian
$ sudo apt-get install rabbitmq-server

For other enviroments check the installation page on the rabbitmq website:
https://www.rabbitmq.com/download.html


Quick start
-----------

1. Add "twitterapi" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'twitterapi',
    ]

2. Include the twitterapi URLconf in your project urls.py like this::

    url(r'^twitterapi/', include('twitterapi.urls')),

3. Run `python manage.py migrate` to create the twitterapi models.

4. Visit http://127.0.0.1:8000/twitterapi/?username=twitterusername to get the twitter profile
